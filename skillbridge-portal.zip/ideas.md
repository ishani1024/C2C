# SkillBridge Design Direction

## Three initial approaches

### Theme Name: Warm Signal
Very Brief Intro: A warm editorial EdTech system that turns career progress into a readable, motivating journey. Navy structure is softened by cream paper tones, rose signals, and blue confidence cues.
Probability: 0.07

### Theme Name: Campus Atlas
Very Brief Intro: A campus-to-career atlas built around modular information panels, route lines, and institutional clarity. The experience feels organized, civic, and quietly optimistic.
Probability: 0.03

### Theme Name: Studio Office Hours
Very Brief Intro: A more expressive student workspace with sticky-note rhythm, oversized type, and tactile cards. Friendly and energetic without losing academic trust.
Probability: 0.09

## Selected Approach: Warm Signal

### Design Movement
Contemporary editorial design blended with Swiss information design and a soft academic dashboard language. The interface should feel like a well-designed student success report: structured, calm, and human.

### Core Principles
1. **Signal before noise:** every color, badge, progress bar, and action should explain a next step.
2. **Editorial hierarchy:** large confident headings, short explanatory copy, and clear sectional rhythm make complex skill data approachable.
3. **Soft structure:** use rounded cards, warm paper backgrounds, and controlled shadows for a tactile but not playful surface.
4. **Progress is visible:** use meters, score rings, skill chips, and status bands to make movement toward industry readiness legible.

### Color Philosophy
The palette is intentionally constrained to the requested five-color system. Deep navy (#3A405A) is the institutional anchor and conveys trust. Soft blue (#AEC5EB) marks possibility, progress, and calm. Warm cream (#F9DEC9) creates a paper-like learning environment. Rose (#E9AFA3) is reserved for signals that need attention, especially skill gaps and gentle nudges. Brown (#685044) grounds supporting text and creates an editorial ink quality. White is used only where necessary for contrast on navy surfaces.

### Layout Paradigm
Use an asymmetric editorial composition rather than centered marketing blocks. Public pages pair a wide text rail with a smaller visual rail; dashboard pages use a fixed navy navigation spine and a calm, offset content canvas. Sections should alternate between full-bleed color bands and dense, readable modules with deliberate whitespace.

### Signature Elements
- A small “bridge mark” made from two offset navy/rose arches, used in the logo, favicon, and dashboard accents.
- Thin route lines and numbered stage markers connecting workflow steps and learning journeys.
- Warm paper cards with small uppercase eyebrow labels, compact metadata rows, and rose status dots.

### Interaction Philosophy
Interactions should feel like guidance, not gamification. Buttons lift slightly and become more solid on hover; filters update content immediately; progress values animate gently once; menus open with clear focus states. Empty or placeholder data should be labeled honestly, and every demo action should explain what it did.

### Animation
Use short, confident transitions under 300ms with a custom ease-out. On initial load, reveal the hero text and visual dashboard in a small stagger. Progress bars and score rings should animate once from zero. Cards can translate upward by a few pixels on hover, but no element should bounce or pulse continuously. Respect prefers-reduced-motion and disable non-essential entrance motion for those users.

### Typography System
Use **DM Serif Display** for high-impact page headlines and **Manrope** for interface text, labels, metadata, and body copy. Headlines use tight leading and occasional italic emphasis for warmth. Body text stays between 15–18px with generous line-height. Eyebrows are uppercase, letter-spaced, and small. Avoid Inter and avoid using a single weight everywhere.

### Brand Essence
SkillBridge helps students turn academic effort into a clear, industry-relevant path through assessment, learning, and opportunity discovery. Personality: **grounded, encouraging, precise**.

### Brand Voice
Headlines are direct and hopeful. CTAs are active and specific. Microcopy is concise, candid, and never overpromises. Avoid generic filler and avoid presenting placeholder SIH statistics as fact.

Example lines:
- “See what your skills can unlock next.”
- “Close the gap, one signal at a time.”

### Wordmark & Logo
The wordmark uses a custom bridge symbol beside “SkillBridge”: two small offset arches crossing a central vertical notch, suggesting the handoff between campus and industry. The symbol is bold and geometric, works without text, and should be used in the header and favicon at a clearly visible size.

### Signature Brand Color
**SkillBridge Navy — #3A405A.** It owns the institutional layer of the product and should be the visual anchor whenever the interface needs authority or focus.

## Style Decisions

- Use only the required five-color palette plus white for contrast.
- Keep the visual system warm, editorial, and student-centered; do not introduce gradients with unrelated colors.
- Preserve honest placeholder labels for any unverified statistics or future API content.
- Use the bridge mark as a recurring visual motif, not a generic star, spark, or shield.
- Make the navy/rose two-arch symbol legible at every primary brand touchpoint.
- Keep product pages anchored by a fixed navy navigation spine, visible meters, score rings, chips, status bands, and route markers.
- Reserve rose for skill gaps, nudges, and attention states; use soft blue for progress and possibility.
